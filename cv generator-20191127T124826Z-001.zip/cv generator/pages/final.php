<!DOCTYPE html>
<html>
<head> 
<title> Complete </title>
<style>
	header { font-family:Hobo Std;
			background-color:grey;
			padding: 5px;
			font-size: 20px;
			text-align:left;
			color:red;			
			}
	footer{	background-color: grey;
			align: bottom;
			padding: 5px;
			text-align: center;
			position: fixed;
			left: 0;
			bottom: 0;
			right:0;
			font-size: 20px;
			color:blue;
		}
	body{
		background-image:url("../images/back2.jpg");
		background-size:cover;
		background-repeat:no-repeat;
		}
	h2{
		font-size: 40px;}
	
</style>
</head>
<body>
<header>
<h1><img src="../images/cv.png" alt="logo" width="50px" height="55px">  CV Builder</h1>
</header>
<center>
<h2> <u>Congrats! Your CV is Ready :) </u></h2>
<a href="../created/open.php"><br>
<img src="../images/view.jpg" alt="view" width="90px" height="90px"><br> Open </a>

<footer><p>ThankYou For using our Website</p>
<a href="../Front.php">Back to main Menu</a></footer>
</center>
</body>
</html>
<?php

?>