<html>
<head>
<title>CV Builder </title>
<style>
	
	header { font-family:Hobo Std;
			background-color:#bbbb;
			padding: 5px;
			font-size: 20px;
			
			color:red;			
			}
	footer{	background-color: #bbbb;
			align: bottom;
			padding: 5px;
			text-align: center;
			position: fixed;
			left: 0;
			bottom: 0;
			right:0;
			font-size: 20px;
			color:blue;
		}
		body{
		background-image:url("images/back2.jpg");
		background-size:cover;
		background-repeat:no-repeat;
	}
	h2{
	font-size: 40px;}

</style>
</head>
<body><center>
<header>
<h1><img src="images/cv.png" alt="logo" width="50px" height="55px"><u>Curriculum Vitae(CV)</u></h1>
</header>
<br><br>
<section class="one">
<a href="pages/basic.php">
<img src="images/create.png" alt="create" width="80px"height="75px"><br> Create New CV</a>
</section><br><br><br>
<footer>
<p> Terms and conditions <br> contact us: 6396922804 || Email:cvbuilder@gmail.com</p>
</footer></center>
</body>
</html>